//let age = window.prompt("How old are you?");
//console.log(typeof age);
//age = Number(age);
//console.log(typeof age);
//age +=1;

//console.log("Happy Birthday! You are", age, "years old")

let x;
let y;
let z;

x = Number("3.14");
y = String(3.14);
z = boolean(""); //false due to nothing parenthesis

console.log(x, type of x);
console.log(y, type of y);
console.log(z, type of z);